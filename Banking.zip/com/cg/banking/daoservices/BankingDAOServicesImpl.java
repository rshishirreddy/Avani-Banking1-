package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transactions;

public class BankingDAOServicesImpl implements BankingDAOServices {
	private HashMap<Integer, Customer>customers=new HashMap<>();
	private static int Customer_Id_Gen=111;
	private static long AccountNo_Id_Gen=20000000;

	@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(Customer_Id_Gen++);
		customers.put(customer.getCustomerId(),customer);
		return customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		account.setAccountNo(AccountNo_Id_Gen++);
		getCustomer(customerId).getAccount().put(account.getAccountNo(), account);
		return account.getAccountNo();
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		getCustomer(customerId).getAccount().put(account.getAccountNo(),account);
		
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public long insertTransaction(int customerId, long accountNo, Transactions transaction) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		customers.remove(customerId);
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		//customers.get(customerId).getAccount().remove(accountNo);
		getCustomer(customerId).getAccount().remove(accountNo);
		
		
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		customers.get(customerId);
		return null;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		return customers.get(customerId).getAccount().get(accountNo);
	}

	@Override
	public List<Customer> getCustomers() {
		
		
		return new ArrayList<Customer>(customers.values());
		
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		
		return new ArrayList<Account>(getCustomer(customerId).getAccount().values());
	}

	@Override
	public List<Transactions> getTransactions(int customerId, long accountNo) {
		return new ArrayList<>(getAccount(customerId, accountNo).getTransactions().values());
	}

}
